#!/usr/bin/env bash
set -euo pipefail
# Adjust USER and paths if needed
VENV="/home/sysop/ws-demo-venv"
export GPIOZERO_PIN_FACTORY=lgpio
export PYTHONPATH="/home/sysop/CM4-NAS-Double-Deck_Demo/RaspberryPi:/usr/lib/python3/dist-packages"
source "$VENV/bin/activate"
cd /home/sysop/CM4-NAS-Double-Deck_Demo/RaspberryPi/example
exec ./sys_dashboard_ws.py
