#!/usr/bin/env python3
# Live system dashboard for Waveshare CM4 NAS 2" LCD
# - Uses vendor driver lib/LCD_2inch.py
# - No gpiozero buttons; pure display
import os, socket, time, math, shutil, subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
try:
    import psutil
except Exception:
    psutil = None

from lib import LCD_2inch  # vendor driver

# -------------------- CONFIG --------------------
ROTATE_180   = True       # matches vendor demo orientation
FONT_MAIN    = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
FONT_ALT_1   = "../Font/Font02.ttf"
FONT_ALT_2   = "../Font/Font01.ttf"
BG_COLOR     = (0, 0, 0)
FG_COLOR     = (255, 255, 255)
ACCENT       = (0, 168, 255)
OK_COLOR     = (96, 173, 76)    # green-ish
WARN_COLOR   = (241, 180, 0)    # amber
BAD_COLOR    = (204, 51, 51)    # red
BAR_BG       = (60, 60, 60)
SPACING      = 4
UPDATE_SEC   = 1.0
DISK_MOUNTS  = ["/"]      # add more mountpoints if you like
NET_IF_PREF  = ("eth","en","wlan")  # prefer these NICs when multiple are found
# ------------------------------------------------

def load_font(size):
    for p in (FONT_MAIN, FONT_ALT_1, FONT_ALT_2):
        try:
            return ImageFont.truetype(p, size)
        except Exception:
            pass
    return ImageFont.load_default()

FONT_BIG   = load_font(26)
FONT_MED   = load_font(18)
FONT_SMALL = load_font(14)
FONT_TINY  = load_font(12)

def bytes2human(n):
    units = ["B","KB","MB","GB","TB","PB","EB"]
    for u in units:
        if n < 1024.0 or u == units[-1]:
            return f"{n:.1f}{u}"
        n /= 1024.0

def get_hostname():
    try:
        return socket.gethostname()
    except:
        return "unknown"

def get_ips():
    ips = []
    # prefer psutil if available
    if psutil:
        for name, addrs in psutil.net_if_addrs().items():
            if not name.startswith(NET_IF_PREF): 
                continue
            for a in addrs:
                fam = getattr(a.family, "name", str(a.family))
                if fam == "AF_INET" and a.address != "127.0.0.1":
                    ips.append((name, a.address))
    # fallback: ip route
    if not ips:
        try:
            out = subprocess.check_output(["ip","-4","addr"], text=True)
            for line in out.splitlines():
                line=line.strip()
                if line.startswith(("inet ")):
                    parts=line.split()
                    addr=parts[1].split("/")[0]
                    ips.append(("ip", addr))
        except Exception:
            pass
    return ips[:2] or [("ip","0.0.0.0")]

def get_cpu_percent():
    # psutil gives a smoothed value if called at intervals
    if psutil:
        return psutil.cpu_percent(interval=None)
    # fallback via /proc/stat delta (coarse)
    try:
        with open("/proc/stat") as f:
            a=f.readline().split()
        time.sleep(0.1)
        with open("/proc/stat") as f:
            b=f.readline().split()
        def t(x): return sum(map(int, x[1:]))
        def idle(x): return int(x[4])
        total=t(a); idle_a=idle(a)
        total2=t(b); idle_b=idle(b)
        dt=total2-total; di=idle_b-idle_a
        return max(0.0, min(100.0, 100.0*(1.0 - (di/dt if dt else 1.0))))
    except Exception:
        return 0.0

def get_loadavg():
    try:
        one, five, fifteen = os.getloadavg()
        return (one, five, fifteen)
    except Exception:
        return (0.0, 0.0, 0.0)

def get_temp_c():
    # Pi SoC temperature (standard path)
    for p in ("/sys/class/thermal/thermal_zone0/temp",
              "/sys/devices/virtual/thermal/thermal_zone0/temp"):
        try:
            v = int(Path(p).read_text().strip())
            return v/1000.0
        except Exception:
            pass
    return None

def get_mem():
    if psutil:
        vm=psutil.virtual_memory()
        return vm.total, vm.used, vm.percent
    # fallback: /proc/meminfo
    try:
        m={}
        with open("/proc/meminfo") as f:
            for line in f:
                k,v=line.split(":")[0], line.split(":")[1].strip().split()[0]
                m[k]=int(v)*1024
        total=m.get("MemTotal",0)
        free =m.get("MemFree",0)+m.get("Buffers",0)+m.get("Cached",0)
        used = total - free
        pct = (used/total*100) if total else 0
        return total, used, pct
    except Exception:
        return 0,0,0

def get_disks(mounts):
    out=[]
    for m in mounts:
        try:
            if psutil:
                u=psutil.disk_usage(m)
                out.append((m, u.total, u.used, u.percent))
            else:
                st=shutil.disk_usage(m)
                pct=st.used/st.total*100 if st.total else 0
                out.append((m, st.total, st.used, pct))
        except Exception:
            continue
    return out

class NetMeter:
    def __init__(self):
        self.last = self._read()
        self.last_t = time.time()
        self.up = 0.0
        self.down = 0.0
    def _read(self):
        if psutil:
            return psutil.net_io_counters()
        # fallback /proc/net/dev
        try:
            with open("/proc/net/dev") as f:
                rx,tx=0,0
                for line in f:
                    if ":" in line:
                        parts=line.split(":")[1].split()
                        rx += int(parts[0])
                        tx += int(parts[8])
                class Simple: pass
                s=Simple(); s.bytes_recv=rx; s.bytes_sent=tx
                return s
        except Exception:
            class Zero: pass
            z=Zero(); z.bytes_recv=0; z.bytes_sent=0
            return z
    def sample(self):
        now = time.time()
        cur = self._read()
        dt = max(0.001, now - self.last_t)
        self.down = (cur.bytes_recv - self.last.bytes_recv)/dt
        self.up   = (cur.bytes_sent - self.last.bytes_sent)/dt
        self.last, self.last_t = cur, now
        return self.down, self.up

def bar(draw, x, y, w, h, pct, fg, bg=BAR_BG, outline=(90,90,90)):
    pct=max(0.0, min(100.0, pct))
    draw.rounded_rectangle((x,y,x+w,y+h), radius=6, outline=outline, width=1, fill=bg)
    fillw = int(w * pct / 100.0)
    if fillw>0:
        draw.rounded_rectangle((x,y,x+fillw,y+h), radius=6, fill=fg)

def pct_color(p):
    if p < 70: return OK_COLOR
    if p < 90: return WARN_COLOR
    return BAD_COLOR

def draw_header(d, W, text):
    tw = d.textlength(text, font=ImageFont.truetype(FONT_MAIN, 26) if Path(FONT_MAIN).exists() else FONT_BIG)
    d.text(((W - tw)//2, 0), text, font=FONT_BIG, fill=FG_COLOR)
    d.line((8, 30, W-8, 30), fill=(80,80,80), width=1)

def main():
    disp = LCD_2inch.LCD_2inch()
    disp.Init()
    disp.clear()

    W, H = disp.height, disp.width   # vendor driver expects (H, W) image
    net = NetMeter()

    host = get_hostname()

    while True:
        img = Image.new("RGB", (W, H), BG_COLOR)
        d   = ImageDraw.Draw(img)

        # Header
        draw_header(d, W, "NAS Status")

        # Row 1: Host + IPs
        y = 36
        d.text((8,y), f"Host: {host}", font=FONT_MED, fill=FG_COLOR); y+=20
        ips = get_ips()
        for name, ip in ips:
            d.text((8,y), f"{name}: {ip}", font=FONT_SMALL, fill=(200,200,200)); y+=18

        # Row 2: CPU + Temp + Load
        y += 4
        cpu = get_cpu_percent()
        load1, load5, load15 = get_loadavg()
        temp = get_temp_c()
        d.text((8,y), "CPU", font=FONT_MED, fill=FG_COLOR)
        bar(d, 50, y+2, 120, 16, cpu, pct_color(cpu))
        d.text((176,y), f"{int(round(cpu))}%", font=FONT_MED, fill=FG_COLOR)
        y+=22
        ttxt = f"Temp: {temp:.1f}°C" if temp is not None else "Temp: n/a"
        d.text((8,y), ttxt, font=FONT_SMALL, fill=(200,200,200))
        d.text((128,y), f"Load: {load1:.2f}/{load5:.2f}/{load15:.2f}", font=FONT_SMALL, fill=(200,200,200))
        y+=18

        # Row 3: Memory
        total, used, mpct = get_mem()
        d.text((8,y), "Mem", font=FONT_MED, fill=FG_COLOR)
        bar(d, 50, y+2, 120, 16, mpct, pct_color(mpct))
        d.text((176,y), f"{int(mpct)}%", font=FONT_MED, fill=FG_COLOR)
        y+=22
        d.text((8,y), f"{bytes2human(used)}/{bytes2human(total)}", font=FONT_SMALL, fill=(200,200,200))
        y+=18

        # Row 4: Disk(s)
        disks = get_disks(DISK_MOUNTS)
        for m, tot, usd, dpct in disks:
            d.text((8,y), m, font=FONT_MED, fill=FG_COLOR)
            bar(d, 50, y+2, 120, 16, dpct, pct_color(dpct))
            d.text((176,y), f"{int(dpct)}%", font=FONT_MED, fill=FG_COLOR)
            y+=22
            d.text((8,y), f"{bytes2human(usd)}/{bytes2human(tot)}", font=FONT_TINY, fill=(200,200,200))
            y+=16

        # Row 5: Network throughput (instantaneous since last frame)
        down, up = net.sample()
        y = H - 24
        d.text((8,y),  f"↓ {bytes2human(down)}/s", font=FONT_SMALL, fill=ACCENT)
        d.text((128,y), f"↑ {bytes2human(up)}/s",   font=FONT_SMALL, fill=ACCENT)

        # Rotate to match enclosure, then display
        if ROTATE_180:
            img = img.rotate(180)

        disp.ShowImage(img)
        time.sleep(UPDATE_SEC)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        # optional: clear screen on exit
        try:
            d = LCD_2inch.LCD_2inch()
            d.Init(); d.clear()
        except Exception:
            pass
        raise
