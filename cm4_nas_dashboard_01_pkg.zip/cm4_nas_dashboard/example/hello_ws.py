#!/usr/bin/env python3
import time
from PIL import Image, ImageDraw, ImageFont
from lib import LCD_2inch

# Change to True if your screen is upside-down (the vendor demo rotates 180)
ROTATE_180 = True

# Pick a font – try DejaVu first, fall back to the bundled one
def load_font(size):
    for path in ("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", "../Font/Font02.ttf", "../Font/Font01.ttf"):
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            pass
    return ImageFont.load_default()

def centered_text(img, text, font):
    d = ImageDraw.Draw(img)
    bbox = d.textbbox((0,0), text, font=font)
    tw, th = (bbox[2]-bbox[0], bbox[3]-bbox[1])
    W, H = img.size
    d.text(((W - tw)//2, (H - th)//2), text, font=font, fill=(255,255,255))

def main():
    disp = LCD_2inch.LCD_2inch()             # SPI0 CE0, DC=25, RST=27, BL=18 by default
    disp.Init()
    disp.clear()

    # Waveshare driver expects image size (height, width)
    img = Image.new("RGB", (disp.height, disp.width), "black")

    font = load_font(34)
    centered_text(img, "Hello World!", font)

    if ROTATE_180:
        img = img.rotate(180)

    disp.ShowImage(img)
    time.sleep(10)  # keep it up for a bit

if __name__ == "__main__":
    main()
