#!/usr/bin/env bash
set -euo pipefail
# One-time system deps
sudo apt update
sudo apt install -y python3-venv python3-gpiozero python3-libgpiod python3-lgpio python3-spidev fonts-dejavu

# Make & activate venv with system site packages so gpio libs are available
python3 -m venv --system-site-packages /home/sysop/ws-demo-venv
source /home/sysop/ws-demo-venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo "Venv ready at /home/sysop/ws-demo-venv"
