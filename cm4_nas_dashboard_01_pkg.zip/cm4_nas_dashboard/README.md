# CM4 NAS Front Display — Clean System Dashboard

This package shows a modern, readable **live system dashboard** on the Waveshare CM4 NAS 2" LCD, using the **official Waveshare driver** (`lib/LCD_2inch.py`).

## Contents
- `example/sys_dashboard_ws.py` — main dashboard script (updates every second)
- `example/hello_ws.py` — quick "Hello World!" test
- `example/run_sys_dashboard.sh` — wrapper used by systemd
- `systemd/nas-display.service` — systemd unit (optional; autostart at boot)
- `requirements.txt` — pip packages for the dashboard
- `env-setup.sh` — helper to install deps & create venv

## Prerequisites
- You already have the Waveshare demo repo at:
  `/home/sysop/CM4-NAS-Double-Deck_Demo/RaspberryPi`
- SPI enabled (`dtparam=spi=on` in `/boot/firmware/config.txt`).
- You can run the official demo (`example/main.py`).

## Install & Run (first time)

```bash
# 1) Unzip this package anywhere, then cd into it:
unzip cm4_nas_dashboard_pkg.zip -d ~/Downloads
cd ~/Downloads/cm4_nas_dashboard

# 2) Install system deps + create venv (uses system site packages for GPIO)
./env-setup.sh

# 3) Copy scripts into the Waveshare example folder
cp -av example/* /home/sysop/CM4-NAS-Double-Deck_Demo/RaspberryPi/example/

# 4) Run the dashboard
source /home/sysop/ws-demo-venv/bin/activate
export GPIOZERO_PIN_FACTORY=lgpio
export PYTHONPATH=/home/sysop/CM4-NAS-Double-Deck_Demo/RaspberryPi:/usr/lib/python3/dist-packages
cd /home/sysop/CM4-NAS-Double-Deck_Demo/RaspberryPi/example
./sys_dashboard_ws.py
```

If the image is upside-down, edit `ROTATE_180` near the top of the script.

## Backlight quick control (optional)
```bash
# ON
for chip in /dev/gpiochip*; do
  if sudo gpioset --chip "$chip" 18=1 2>/dev/null; then break; fi
done
# OFF
for chip in /dev/gpiochip*; do
  if sudo gpioset --chip "$chip" 18=0 2>/dev/null; then break; fi
done
```

## Start at Boot (systemd)

```bash
# 1) Install the unit
sudo cp systemd/nas-display.service /etc/systemd/system/

# 2) Enable and start
sudo systemctl daemon-reload
sudo systemctl enable --now nas-display.service

# 3) Check status/logs
systemctl --user status nas-display.service 2>/dev/null || true
sudo journalctl -u nas-display.service -e
```

The service calls `example/run_sys_dashboard.sh`, which activates the venv and launches the dashboard with the correct environment variables.

## Updating later
Just overwrite `example/sys_dashboard_ws.py` with your new version, then restart:
```bash
sudo systemctl restart nas-display.service
```

## Troubleshooting

- **Black screen or flicker**: Verify the official demo still runs. If not, try CE1 and/or lower the SPI speed inside `lib/lcdconfig.py` (e.g., 12MHz).
- **Import errors**: Ensure you activated the venv (`source /home/sysop/ws-demo-venv/bin/activate`) and exported `PYTHONPATH` to include the Waveshare repo:  
  `/home/sysop/CM4-NAS-Double-Deck_Demo/RaspberryPi`
- **Upside-down**: Set `ROTATE_180 = False` in the script.
- **Show more disks**: Edit `DISK_MOUNTS = ["/", "/mnt/disk1", "/mnt/disk2"]`.
- **Refresh rate**: Change `UPDATE_SEC` (e.g., `0.5` or `2.0`).

---

Happy dashing! ✨
